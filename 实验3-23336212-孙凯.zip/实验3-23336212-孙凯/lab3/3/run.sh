#!/bin/bash
qemu-system-i386 -hda hd1.img -serial null -parallel stdio