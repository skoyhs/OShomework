#!/bin/bash
qemu-system-i386 -hda hd.img -serial null -parallel stdio